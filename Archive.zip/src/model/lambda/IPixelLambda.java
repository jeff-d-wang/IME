package model.lambda;

/**
 * Interface for lambdas mutating IPixels.
 */
public interface IPixelLambda {

}
